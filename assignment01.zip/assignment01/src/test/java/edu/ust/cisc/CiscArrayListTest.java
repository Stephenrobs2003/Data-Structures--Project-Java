package edu.ust.cisc;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class CiscArrayListTest extends CiscTest {
    private CiscArrayList<Integer> ciscArrayList;
    private Field elementData;
    private Field size;
    private Method ensureCapacity;
    private Class<?> iteratorClass;
    private Field nextIndex;

    @BeforeEach
    void setUp() throws Exception {
        ciscArrayList = new CiscArrayList<Integer>();
        elementData = CiscArrayList.class.getDeclaredField("elementData");
        elementData.setAccessible(true);
        size = CiscArrayList.class.getDeclaredField("size");
        size.setAccessible(true);
        ensureCapacity = CiscArrayList.class.getDeclaredMethod("ensureCapacity", int.class);
        ensureCapacity.setAccessible(true);

        iteratorClass = Class.forName("edu.ust.cisc.CiscArrayList$CiscArrayListIterator");
        nextIndex = iteratorClass.getDeclaredField("nextIndex");
        nextIndex.setAccessible(true);
    }

    @Test
    public void testFields() {
        try {
            assertEquals(3, CiscArrayList.class.getDeclaredFields().length, "CiscArrayList should only have \"DEFAULT_CAPACITY\", \"elementData\" and \"size\" fields");
        } catch(Exception e) {
            e.printStackTrace();
            fail("Exception thrown when attempting to access CiscArrayList fields");
        }
    }

    @Test
    public void testDefaultConstructor() {
        String methodCall = "CiscArrayList()";
        try {
            assertExpectedCiscArrayList(new Object[10], 0, methodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testConstructorWithCapacity() {
        String methodCall = "CiscArrayList(20)";
        try {
            ciscArrayList = new CiscArrayList<Integer>(20);
            assertExpectedCiscArrayList(new Object[20], 0, methodCall);

            //try negative index
            methodCall = "CiscArrayList(-20)";
            assertThrows(IllegalArgumentException.class, () -> {
                new CiscArrayList<>(-20);
            }, generateErrorMessage(methodCall, "thrown exception"));
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testSize() {
        String methodCall = "size()";
        try {
            Random r = new Random();
            int s = r.nextInt(100);
            size.set(ciscArrayList, s);
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertExpectedCiscArrayList(new Object[10], s, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* iterator tests *************************************************************************************************/

    @Test
    public void testIteratorFields() {
        try {
            assertEquals(2, iteratorClass.getDeclaredFields().length, "CiscArrayListIterator should only have a single \"nextIndex\" field");
        } catch(Exception e) {
            e.printStackTrace();
            fail("Exception thrown when attempting to access CiscArrayListIterator fields");
        }
    }

    @Test
    public void testIterator() {
        String methodCall = "iterator()";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            Iterator<Integer> itr = ciscArrayList.iterator();
            assertEquals(iteratorClass, itr.getClass(), generateErrorMessage(methodCall, "return value type", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIteratorHasNextEmpty() {
        String methodCall = "hasNext()";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            Iterator<Integer> itr = ciscArrayList.iterator();
            assertEquals(false, itr.hasNext(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIteratorHasNextNonEmpty() {
        String methodCall = "hasNext()";
        try {
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            Iterator<Integer> itr = ciscArrayList.iterator();
            assertEquals(true, itr.hasNext(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIteratorHasNextNonEmptyAndFinished() {
        String methodCall = "hasNext()";
        try {
            //test with partially filled array
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            Iterator<Integer> itr = ciscArrayList.iterator();
            nextIndex.set(itr, 1);
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(false, itr.hasNext(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);

            //test with filled array
            Object[] ed = {1,2,3,4,5,6,7,8,9,10};
            elementData.set(ciscArrayList, ed);
            size.set(ciscArrayList, 10);
            itr = ciscArrayList.iterator();
            nextIndex.set(itr, 10);
            calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(false, itr.hasNext(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 10, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIteratorNextEmpty() {
        String methodCall = "next()";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            Iterator<Integer> itr = ciscArrayList.iterator();
            assertThrows(NoSuchElementException.class, () -> {
                itr.next();
            }, generateErrorMessage(methodCall, "thrown exception"));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIteratorNextNonEmpty() {
        String methodCall = "next()";
        try {
            List<Integer> list = getRandomIntArrayList(10, false);
            elementData.set(ciscArrayList, list.toArray());
            size.set(ciscArrayList, 10);
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            Iterator<Integer> itr = ciscArrayList.iterator();
            for(int i=0; i<10; i++) {
                calBeforeMethodCall = duplicateCiscArrayList();
                assertEquals(list.get(i), itr.next(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            }
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 10, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* add tests ******************************************************************************************************/

    @Test
    public void testAddNullArgument() {
        String methodCall = "add(null)";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.add(null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(new Integer[10], 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testAdd() {
        String methodCall = "add(E)";
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] randomIntsArr = new Object[10];
            int randomInt;
            boolean r;
            CiscArrayList<Integer> calBeforeMethodCall;
            for (int i = 0; i < numInts; i++) {
                randomInt = randomInts.get(i);
                randomIntsArr[i] = randomInt;
                methodCall = "add(" + randomInt + ")";
                calBeforeMethodCall = duplicateCiscArrayList();

                r = ciscArrayList.add(randomInt);
                assertEquals(true, r, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(randomIntsArr, i+1, methodCall, calBeforeMethodCall);
            }
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testAddWithReallocate() {
        String methodCall = "add(E)";
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] ed = randomInts.toArray();
            elementData.set(ciscArrayList, ed);
            size.set(ciscArrayList, 10);
            int randomInt = new Random().nextInt(100);
            Object[] expectedArr = Arrays.copyOf(ed, 21);
            expectedArr[10] = randomInt;
            methodCall = "add("+randomInt+")";
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            boolean r = ciscArrayList.add(randomInt);
            assertEquals(true, r, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedArr, 11, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* addAll tests ***************************************************************************************************/

    @Test
    public void testAddAllWithNulls() {
        String methodCall = "addAll(null)";
        try {
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.addAll(null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);

            methodCall = "addAll(CiscArrayList with null element)";
            CiscArrayList<Integer> argument = new CiscArrayList<>();
            size.set(argument, 1);
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.addAll(argument);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testAddAllWithEmptyArgument() {
        String methodCall = "addAll(new CiscArrayList<>())";
        try {
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();

            //case 1 - empty calling argument
            //should return false without any changes to elementData or size
            boolean retValue = ciscArrayList.addAll(new CiscArrayList<>());
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);

            //case 2 - non-empty calling argument
            //should return false without any changes to elementData or size
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            calBeforeMethodCall  = duplicateCiscArrayList();

            retValue = ciscArrayList.addAll(new CiscArrayList<>());
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testAddAllWithoutReallocate() {
        String methodCall = "addAll([5,6,7,8,9,10])";
        try {
            Object[] four = {1,2,3,4,null,null,null,null,null,null};
            elementData.set(ciscArrayList, four);
            size.set(ciscArrayList, 4);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();

            Object[] six = {5,6,7,8,9,10,null,null,null,null};
            CiscArrayList argumentList = new CiscArrayList();
            elementData.set(argumentList, six);
            size.set(argumentList, 6);
            Object[] expectedElementData = {1,2,3,4,5,6,7,8,9,10};

            //should return true with updates to elementData or size without reallocation
            boolean retValue = ciscArrayList.addAll(argumentList);
            assertEquals(true, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, 10, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testAddAllWithReallocate() {
        String methodCall = "addAll([5,6,7,8,9,10,11])";
        try {
            Object[] ten = {1,2,3,4,5,6,7,8,9,10};
            elementData.set(ciscArrayList, ten);
            size.set(ciscArrayList, 10);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();

            Object[] twelve = {1,2,3,4,5,6,7,8,9,10,11,12,null,null,null,null,null,null,null,null,null};
            CiscArrayList argumentList = new CiscArrayList();
            elementData.set(argumentList, twelve);
            size.set(argumentList, 12);
            Object[] expectedElementData = {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,11,12};

            //should return true with updates to elementData or size without reallocation
            boolean retValue = ciscArrayList.addAll(argumentList);
            assertEquals(true, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, 22, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* remove tests ***************************************************************************************************/

    @Test
    public void testRemoveWithNull() {
        String methodCall = "remove(null)";
        try {
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.remove(null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testRemoveNotPresent() {
        String methodCall = "remove(E)";
        try {
            Random r = new Random();
            int randInt = r.nextInt(100);
            methodCall = "remove(" + randInt + ")";
            Object[] ed = new Object[10];
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            //case 1: remove from empty list
            boolean retValue = ciscArrayList.remove((Object)randInt);
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);

            for(int i=0; i<10; i++) {
                ed[i] = randInt;
            }
            elementData.set(ciscArrayList, ed);
            calBeforeMethodCall = duplicateCiscArrayList();

            //case 2: remove from non-empty list and ensure size is used
            retValue = ciscArrayList.remove((Object)randInt);
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testRemove() {
        String methodCall = "remove(E)";
        try {
            ArrayList<Integer> randomInts;
            Object[] ciscElementData;
            Random r;
            int randInt;
            CiscArrayList<Integer> calBeforeMethodCall;

            int numInts = 10;
            randomInts = getRandomIntArrayList(numInts, true);
            Object[] outputArray = new Object[10];
            ciscElementData = (Object[]) elementData.get(ciscArrayList);

            //setup ciscArrayList
            for (int i = 0; i < numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);
            r = new Random();
            randInt = r.nextInt(100) + 100;
            methodCall = "remove("+randInt+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            //test non-existent element
            assertEquals(false, ciscArrayList.remove((Object) randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(randomInts.toArray(outputArray), 10, methodCall, calBeforeMethodCall);

            //test element at end
            randInt = randomInts.remove(numInts-1);
            methodCall = "remove("+randInt+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(true, ciscArrayList.remove((Object) randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(randomInts.toArray(outputArray), randomInts.size(), methodCall, calBeforeMethodCall);
            numInts--;

            //test element at start
            randInt = randomInts.remove(0);
            methodCall = "remove("+randInt+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(true, ciscArrayList.remove((Object) randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(randomInts.toArray(outputArray), randomInts.size(), methodCall, calBeforeMethodCall);
            numInts--;

            //repeatedly remove random element from ciscArrayList
            for (int i = 0; i < numInts; i++) {
                randInt = randomInts.get(r.nextInt(randomInts.size()));
                methodCall = "remove("+randInt+")";
                calBeforeMethodCall = duplicateCiscArrayList();
                randomInts.remove((Object) randInt);
                assertEquals(true, ciscArrayList.remove((Object) randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(randomInts.toArray(outputArray), randomInts.size(), methodCall, calBeforeMethodCall);
            }

        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* contains tests *************************************************************************************************/

    @Test
    public void testContainsWithNull() {
        String methodCall = "contains(null)";
        try {
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.contains(null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testContainsNotPresent() {
        String methodCall = "contains(E)";
        try {
            Random r = new Random();
            int randInt = r.nextInt(100);
            methodCall = "contains(" + randInt + ")";
            Object[] ed = new Object[10];
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            //case 1: empty list
            boolean retValue = ciscArrayList.contains(randInt);
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);

            for(int i=0; i<10; i++) {
                ed[i] = randInt;
            }
            elementData.set(ciscArrayList, ed);
            calBeforeMethodCall = duplicateCiscArrayList();

            //case 2: empty list and ensure size is used
            retValue = ciscArrayList.contains(randInt);
            assertEquals(false, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testContains() {
        String methodCall = "contains(E)";
        try {
            Random r = new Random();
            CiscArrayList<Integer> calBeforeMethodCall;

            int randInt = r.nextInt(100);
            methodCall = "contains("+randInt+")";
            calBeforeMethodCall = duplicateCiscArrayList();

            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, true);
            Object[] randomIntsArr = randomInts.toArray();
            elementData.set(ciscArrayList, randomInts.toArray());
            size.set(ciscArrayList, numInts);

            for(int i=0; i<numInts; i++) {
                randInt = randomInts.get(i);
                methodCall = "contains("+randInt+")";
                calBeforeMethodCall = duplicateCiscArrayList();
                assertEquals(true, ciscArrayList.contains(randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(randomIntsArr, numInts, methodCall, calBeforeMethodCall);
            }

            //ensure size is used
            size.set(ciscArrayList, numInts-1);
            assertEquals(false, ciscArrayList.contains(randomInts.get(9)), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(randomIntsArr, numInts-1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* isEmpty tests **************************************************************************************************/

    @Test
    public void testIsEmpty() {
        String methodCall = "isEmpty()";
        try {
            Random r = new Random();
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(true, ciscArrayList.isEmpty(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(new Object[10], 0, methodCall, calBeforeMethodCall);

            int randInt = r.nextInt(100);
            Object[] expectedElementData = {randInt,null,null,null,null,null,null,null,null,null};
            ((Object[])elementData.get(ciscArrayList))[0] = randInt;
            size.set(ciscArrayList, 1);
            calBeforeMethodCall = duplicateCiscArrayList();
            assertEquals(false, ciscArrayList.isEmpty(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* clear tests ****************************************************************************************************/

    @Test
    public void testClear() {
        String methodCall = "clear()";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            ciscArrayList.clear();
            Object[] ciscElementData = ((Object[])elementData.get(ciscArrayList));
            assertExpectedCiscArrayList(new Object[10], 0, methodCall, calBeforeMethodCall);

            Random r = new Random();
            int numInts = 10;
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = r.nextInt(100);
            }
            size.set(ciscArrayList, numInts);
            calBeforeMethodCall = duplicateCiscArrayList();
            ciscArrayList.clear();
            assertExpectedCiscArrayList(new Object[10], 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* toArray tests **************************************************************************************************/

    @Test
    public void testToArray() {
        String methodCall = "toArray()";
        try {
            int numInts = 7;
            Object[] ciscElementData = ((Object[])elementData.get(ciscArrayList));
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] expectedElementData = new Object[10];
            randomInts.toArray(expectedElementData);
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            assertArrayEquals(randomInts.toArray(), ciscArrayList.toArray(), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testToArrayWithEmptyList() {
        String methodCall = "toArray()";
        try {
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertNotNull(ciscArrayList.toArray(), generateErrorMessage(methodCall, "non-null return value", calBeforeMethodCall));
            assertEquals(0, ciscArrayList.toArray().length, generateErrorMessage(methodCall, "return value capacity", calBeforeMethodCall));
            assertExpectedCiscArrayList(new Object[10], 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* insert tests ***************************************************************************************************/

    @Test
    public void testInsertWithNull() {
        String methodCall = "add(0, null)";
        try {
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.add(0, null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testInsert() {
        String methodCall = "add(int, E)";
        try {
            int numInts = 10;
            ArrayList<Integer> checkList = new ArrayList();
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            Random r = new Random();
            int randIndex;
            Integer randVal;
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                randIndex = r.nextInt(checkList.size()+1);
                randVal = r.nextInt(100);
                methodCall = "add("+randIndex+","+randVal+")";
                calBeforeMethodCall = duplicateCiscArrayList();
                checkList.add(randIndex, randVal);

                ciscArrayList.add(randIndex, randVal);
                assertExpectedCiscArrayList(Arrays.copyOf(checkList.toArray(), ciscElementData.length), checkList.size(), methodCall, calBeforeMethodCall);
            }
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testInsertWithInvalidIndex() {
        String methodCall = "add(int, E)";
        try {
            int numInts = 7;
            Random r = new Random();
            Object[] ciscElementData = ((Object[])elementData.get(ciscArrayList));
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] expectedElementData = new Object[10];
            randomInts.toArray(expectedElementData);
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //try negative index
            final int randValue = r.nextInt(100);
            methodCall = "add(-1,"+randValue+")";
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.add(-1, randValue);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);

            //try index too large
            methodCall = "add("+(numInts+1)+","+randValue+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.add(numInts+1, randValue);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* get tests ******************************************************************************************************/

    @Test
    public void testGet() {
        String methodCall = "get(int)";
        try {
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            Random r = new Random();
            int numInts = 10;
            int randInt;
            Object[] expectedElementData = new Object[numInts];
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = r.nextInt(100);
                expectedElementData[i] = ciscElementData[i];
            }
            size.set(ciscArrayList, numInts);

            for(int i=0; i<numInts; i++) {
                calBeforeMethodCall = duplicateCiscArrayList();
                randInt = ciscArrayList.get(i);
                methodCall = "get("+randInt+")";
                assertEquals(ciscElementData[i], randInt, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
            }
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testGetWithInvalidIndex() {
        String methodCall = "get(int)";
        try {
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            Random r = new Random();
            int numInts = 7;
            Object[] expectedElementData = new Object[10];
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = r.nextInt(100);
                expectedElementData[i] = ciscElementData[i];
            }
            size.set(ciscArrayList, numInts);

            //try negative index
            methodCall = "get(-1)";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.get(-1);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);

            //try index too large
            methodCall = "get("+numInts+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.get(numInts);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* indexOf tests **************************************************************************************************/

    @Test
    public void testIndexOfWithNull() {
        String methodCall = "indexOf(null)";
        try {
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.indexOf(null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIndexOf() {
        String methodCall = "indexOf(E)";
        try {
            Random r = new Random();
            CiscArrayList<Integer> calBeforeMethodCall;

            int randInt = r.nextInt(100);
            methodCall = "indexOf("+randInt+")";
            calBeforeMethodCall = duplicateCiscArrayList();

            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, true);
            Object[] randomIntsArr = randomInts.toArray();
            elementData.set(ciscArrayList, randomInts.toArray());
            size.set(ciscArrayList, numInts);

            for(int i=0; i<numInts; i++) {
                randInt = randomInts.get(i);
                methodCall = "indexOf("+randInt+")";
                calBeforeMethodCall = duplicateCiscArrayList();
                assertEquals(i, ciscArrayList.indexOf(randInt), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(randomIntsArr, numInts, methodCall, calBeforeMethodCall);
            }

            //ensure size is used
            size.set(ciscArrayList, numInts-1);
            assertEquals(-1, ciscArrayList.indexOf(randomInts.get(9)), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(randomIntsArr, numInts-1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testIndexOfNotPresent() {
        String methodCall = "indexOf(E)";
        try {
            Random r = new Random();
            int randInt = r.nextInt(100);
            methodCall = "indexOf(" + randInt + ")";
            Object[] ed = new Object[10];
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();

            //case 1: empty list
            int retValue = ciscArrayList.indexOf(randInt);
            assertEquals(-1, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);

            for(int i=0; i<10; i++) {
                ed[i] = randInt;
            }
            elementData.set(ciscArrayList, ed);
            calBeforeMethodCall = duplicateCiscArrayList();

            //case 2: empty list and ensure size is used
            retValue = ciscArrayList.indexOf(randInt);
            assertEquals(-1, retValue, generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
            assertExpectedCiscArrayList(ed, 0, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* removeAtIndex tests ********************************************************************************************/

    @Test
    public void testRemoveAtIndex() {
        String methodCall = "remove(int)";
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            CiscArrayList<Integer> calBeforeMethodCall;

            //setup ciscArrayList
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);
            Random r = new Random();
            int randomIndex;

            //repeatedly remove random element from ciscArrayList
            for(int i=0; i<numInts; i++) {
                randomIndex = r.nextInt(randomInts.size());
                methodCall = "remove("+randomIndex+")";
                calBeforeMethodCall = duplicateCiscArrayList();

                assertEquals(randomInts.remove(randomIndex), ciscArrayList.remove(randomIndex), generateErrorMessage(methodCall, "return value", calBeforeMethodCall));
                assertExpectedCiscArrayList(Arrays.copyOf(randomInts.toArray(), numInts), randomInts.size(), methodCall, calBeforeMethodCall);
            }
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testRemoveAtIndexWithInvalidIndex() {
        String methodCall = "remove(int)";
        try {
            int numInts = 7;
            Random r = new Random();
            Object[] ciscElementData = ((Object[])elementData.get(ciscArrayList));
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] expectedElementData = new Object[10];
            randomInts.toArray(expectedElementData);
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //try negative index
            methodCall = "remove(-1)";
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.remove(-1);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);

            //try index too large
            methodCall = "remove("+numInts+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.remove(numInts);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* set tests ******************************************************************************************************/

    @Test
    public void testSetWithNull() {
        String methodCall = "set(0, null)";
        try {
            ((Object[])elementData.get(ciscArrayList))[0] = 3;
            size.set(ciscArrayList, 1);
            CiscArrayList<Integer> calBeforeMethodCall  = duplicateCiscArrayList();
            assertThrows(NullPointerException.class, () -> {
                ciscArrayList.set(0, null);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList((Object[])elementData.get(calBeforeMethodCall), 1, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testSet() {
        String methodCall = "set(int, E)";
        try {
            int numInts = 10;
            ArrayList<Integer> checkList = new ArrayList();
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            Random r = new Random();
            int randIndex;
            Integer randVal;
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                randVal = r.nextInt(100);
                checkList.add(randVal);
                ciscElementData[i] = randVal;
                size.set(ciscArrayList, i+1);
                randIndex = r.nextInt(checkList.size());
                randVal = r.nextInt(100);
                checkList.set(randIndex, randVal);
                methodCall = "set("+randIndex+","+randVal+")";
                calBeforeMethodCall = duplicateCiscArrayList();

                ciscArrayList.set(randIndex, randVal);
                assertExpectedCiscArrayList(Arrays.copyOf(checkList.toArray(), 10), i+1, methodCall, calBeforeMethodCall);
            }
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testSetWithInvalidIndex() {
        String methodCall = "set(int, E)";
        try {
            int numInts = 7;
            Random r = new Random();
            Object[] ciscElementData = ((Object[])elementData.get(ciscArrayList));
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] expectedElementData = new Object[10];
            randomInts.toArray(expectedElementData);
            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //try negative index
            final int randomValue = r.nextInt(100);
            methodCall = "set(-1,"+randomValue+")";
            CiscArrayList<Integer> calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.set(-1, randomValue);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);

            //try index too large
            methodCall = "set("+numInts+","+randomValue+")";
            calBeforeMethodCall = duplicateCiscArrayList();
            assertThrows(IndexOutOfBoundsException.class, () -> {
                ciscArrayList.set(numInts, randomValue);
            }, generateErrorMessage(methodCall, "thrown exception", calBeforeMethodCall));
            assertExpectedCiscArrayList(expectedElementData, numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /* ensureCapacity tests *******************************************************************************************/

    @Test
    public void testEnsureCapacityNoReallocate() {
        String methodCall = "ensureCapacity(int)";
        assertEquals(2, ensureCapacity.getModifiers(), generateErrorMessage(methodCall, "method modifiers (e.g. public/private, static, final)"));
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //shouldn't result in ensureCapacity array resizing
            methodCall = "ensureCapacity("+numInts+")";
            calBeforeMethodCall = duplicateCiscArrayList();

            ensureCapacity.invoke(ciscArrayList, numInts);
            assertExpectedCiscArrayList(randomInts.toArray(), numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testEnsureCapacityReallocateToDoublePlus1() {
        String methodCall = "ensureCapacity(int)";
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //should result in ensureCapacity array resizing
            methodCall = "ensureCapacity("+(numInts+1)+")";
            calBeforeMethodCall = duplicateCiscArrayList();

            ensureCapacity.invoke(ciscArrayList, numInts+1);
            assertExpectedCiscArrayList(Arrays.copyOf(randomInts.toArray(), 21), numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    @Test
    public void testEnsureCapacityReallocateToParameter() {
        String methodCall = "ensureCapacity(int)";
        try {
            int numInts = 10;
            ArrayList<Integer> randomInts = getRandomIntArrayList(numInts, false);
            Object[] ciscElementData = (Object[])elementData.get(ciscArrayList);
            CiscArrayList<Integer> calBeforeMethodCall;

            for(int i=0; i<numInts; i++) {
                ciscElementData[i] = randomInts.get(i);
            }
            size.set(ciscArrayList, numInts);

            //should result in ensureCapacity array resizing
            methodCall = "ensureCapacity("+(numInts*2+2)+")";
            calBeforeMethodCall = duplicateCiscArrayList();

            ensureCapacity.invoke(ciscArrayList, numInts*2+2);
            assertExpectedCiscArrayList(Arrays.copyOf(randomInts.toArray(), numInts*2+2), numInts, methodCall, calBeforeMethodCall);
        } catch (Exception e) {
            handleGenericException(methodCall, e);
        }
    }

    /******************************************************************************************************************/

    private ArrayList<Integer> getRandomIntArrayList(int size, boolean allUnique) {
        ArrayList<Integer> randomInts = new ArrayList<Integer>();
        Random r = new Random();
        int randomInt;
        for(int i=0; i<size; i++) {
            do {
                randomInt = r.nextInt(100);
            } while(allUnique && randomInts.contains(randomInt));
            randomInts.add(randomInt);
        }
        return randomInts;
    }

    private CiscArrayList duplicateCiscArrayList() {
        CiscArrayList cal = new CiscArrayList();
        try {
            Object[] ed = (Object[])elementData.get(ciscArrayList);
            Object[] edCopy = new Object[ed.length];
            for(int i=0; i<edCopy.length; i++) {
                if(ed[i] != null) {
                    edCopy[i] = Integer.valueOf((Integer) ed[i]);
                }
            }
            elementData.set(cal, edCopy);
            size.set(cal, size.get(ciscArrayList));
        } catch(Exception e) {
            e.printStackTrace();
        }
        return cal;
    }

    private void assertExpectedCiscArrayList(Object[] expectedElementData, int expectedSize, String methodCall) throws IllegalAccessException {
        assertArrayEquals(expectedElementData, (Object[]) elementData.get(ciscArrayList), generateErrorMessage(methodCall, "elementData"));
        assertEquals(0, size.get(ciscArrayList), generateErrorMessage(methodCall, "size"));
    }

    private void assertExpectedCiscArrayList(Object[] expectedElementData, int expectedSize, String methodCall, CiscArrayList calBeforeMethodCall) throws IllegalAccessException {
        assertArrayEquals(expectedElementData, (Object[]) elementData.get(ciscArrayList), generateErrorMessage(methodCall, "elementData", calBeforeMethodCall));
        assertEquals(expectedSize, size.get(ciscArrayList), generateErrorMessage(methodCall, "size", calBeforeMethodCall));
    }

    @Override
    protected String generateIllustration(Object ciscDataStructure) {
        StringBuilder sb = new StringBuilder();
        try {
            sb.append("\telementData: " + Arrays.toString((Object[]) elementData.get(ciscDataStructure)));
            sb.append("\n\tsize: " + size.get(ciscDataStructure));
        } catch(Exception e) {
            sb.append(e.getStackTrace());
        }
        return sb.toString();
    }

    @Override
    protected String generateIllustration() {
        return generateIllustration(ciscArrayList);
    }
}